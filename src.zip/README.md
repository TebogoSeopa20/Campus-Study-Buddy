# Wits Campus Study Buddy
### Wits Campus Study Buddy is an academic collaboration platform designed to help university students improve their learning experience through connection, structure, and support. It allows students to find compatible study partners based on shared modules and interests, create or join study groups, schedule group sessions, and track their academic progress over time. By combining social features with productivity tools, Campus Study Buddy builds a supportive digital community where students can collaborate, stay organized, and succeed together in their university journey.

## How to push to a new branch
### git pull origin main
### git add .
### git checkout -b name-of-new-branch
### git commit -m "commit message"
### git push origin name-of-new-branch

## How to run the App locally
### npm start
